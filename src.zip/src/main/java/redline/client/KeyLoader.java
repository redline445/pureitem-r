package redline.client;

import cpw.mods.fml.client.registry.ClientRegistry;
import net.minecraft.client.settings.KeyBinding;
import org.lwjgl.input.Keyboard;
//按键
public class KeyLoader
{
    public static KeyBinding forward;
    public static KeyBinding back;
    public static KeyBinding lift;
    public static KeyBinding right;
    public KeyLoader()
    {
    }
}