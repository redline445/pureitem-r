package redline.item;

import net.minecraft.item.Item;
import redline.Tab.TabsLoader;

public class Fire extends Item {
public Fire(){
    super();
    this.setUnlocalizedName("");
    this.setTextureName("redline:fire");
}
}
